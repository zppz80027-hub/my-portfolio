Replace resume.pdf, profile.jpg, and project/certificate assets with your real files. The app uses graceful placeholders when optional images are absent.
