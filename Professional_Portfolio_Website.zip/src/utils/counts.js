export const countWithPlus = n => `${String(n).padStart(2,'0')}+`;
