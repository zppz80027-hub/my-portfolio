import { Github, Linkedin, Mail } from 'lucide-react';
import { personal } from './personal';
export const socialLinks = [
  { label:'GitHub', href:personal.github, icon:Github },
  { label:'LinkedIn', href:personal.linkedin, icon:Linkedin },
  { label:'Email', href:`mailto:${personal.email}`, icon:Mail }
];
