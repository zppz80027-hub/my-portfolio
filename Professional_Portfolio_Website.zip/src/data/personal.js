export const personal = {
  name: '[YOUR NAME]',
  firstName: '[YOUR NAME]',
  role: 'Developer • AI Enthusiast • Problem Solver',
  headline: 'I build modern web applications, intelligent systems, and practical technology solutions.',
  availability: 'Open to Opportunities',
  bio: 'I am a developer who enjoys turning real-world problems into useful software. My interests span web development, artificial intelligence, problem solving, hackathons, and continuous learning.',
  objective: 'I aim to build impactful software solutions while continuously improving my technical skills and exploring emerging technologies.',
  college: '[YOUR COLLEGE]',
  degree: '[YOUR DEGREE / COURSE]',
  email: '[YOUR EMAIL]',
  github: 'https://github.com/yourusername',
  linkedin: 'https://www.linkedin.com/in/yourusername',
  location: '[YOUR LOCATION]',
  resume: '/resume.pdf',
  photo: '/profile.svg'
};
