export const skills = [
 { name:'HTML', level:85, category:'Frontend' }, { name:'CSS', level:82, category:'Frontend' }, { name:'JavaScript', level:78, category:'Frontend' }, { name:'React.js', level:75, category:'Frontend' },
 { name:'Python', level:70, category:'Backend' }, { name:'FastAPI', level:60, category:'Backend' }, { name:'MongoDB', level:55, category:'Database' },
 { name:'Git', level:75, category:'Tools' }, { name:'GitHub', level:78, category:'Tools' }, { name:'VS Code', level:90, category:'Tools' },
 { name:'AI / ML', level:40, category:'AI / ML' }, { name:'LLMs', level:40, category:'AI / ML' }, { name:'AI APIs', level:45, category:'AI / ML' }
];
export const learning = [
 { name:'TypeScript', progress:45, goal:'Build safer, scalable React applications.' },
 { name:'AI / Machine Learning', progress:40, goal:'Develop practical intelligent features and agents.' },
 { name:'Cloud Computing', progress:25, goal:'Learn deployment, infrastructure and cloud architecture.' },
 { name:'Docker', progress:25, goal:'Containerize applications for reliable development and deployment.' }
];
