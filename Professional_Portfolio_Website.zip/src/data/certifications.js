export const certifications = [{ title:'[CERTIFICATION NAME]', issuer:'[ISSUER]', date:'[DATE]', credentialId:'[CREDENTIAL ID]', credentialUrl:'', image:'' }];
