import { useEffect, useState } from 'react';
export function useTheme(){ const [theme,setTheme]=useState(()=>localStorage.getItem('portfolio-theme')||'dark'); useEffect(()=>{document.documentElement.dataset.theme=theme;localStorage.setItem('portfolio-theme',theme)},[theme]); return [theme,setTheme]; }
