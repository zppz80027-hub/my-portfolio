# Professional Developer Portfolio

A premium, responsive React + Vite portfolio designed around a centralized, data-driven architecture. The UI is intentionally independent from portfolio content so the site can grow with new projects, skills, certifications, achievements and experience.

## Features
- Premium dark/light responsive design
- Data-driven portfolio content
- Project search, category filtering and detail modal
- Animated sections and skill progress indicators
- Currently-learning area
- Education/experience timeline
- Hackathons, achievements and certifications
- Accessible contact form with optional API endpoint and mailto fallback
- Resume download from `public/resume.pdf`
- Reduced-motion support
- SEO metadata, robots.txt and sitemap placeholder
- No secrets in frontend source

## Tech Stack
- React 19
- Vite
- Framer Motion
- Lucide React
- Custom CSS design system (no UI framework dependency)

The CSS approach keeps the project lightweight and makes the visual system easy to customize without adding a large styling runtime.

## Installation
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm run preview
```

## How to update portfolio data
All content lives under `src/data/`.

### Personal details
Edit `src/data/personal.js`:
- name, role, bio, objective
- email, GitHub, LinkedIn
- college/degree/location
- resume and profile image paths

### Skills
Edit `src/data/skills.js`. Add objects like:
```js
{ name: 'TypeScript', level: 65, category: 'Frontend' }
```
The UI automatically creates a category when it appears in the data.

### Currently learning
Add/edit items in the `learning` array in `src/data/skills.js`.

### Projects
Edit `src/data/projects.js`. A project can contain:
```js
{
  id: 'new-project',
  title: 'My New Project',
  shortDescription: '...',
  description: '...',
  technologies: ['React', 'Python'],
  category: 'Full Stack',
  categories: ['Full Stack', 'Web'],
  year: '2026',
  status: 'In Progress',
  featured: true,
  image: '/projects/project.png',
  github: 'https://github.com/...',
  demo: 'https://...'
}
```
Project filters are generated from project categories, so new categories appear automatically.

### Education and experience
Edit `src/data/education.js` and `src/data/experience.js`. Add another object to each array to add a timeline entry.

### Achievements and hackathons
Edit `src/data/achievements.js`.

### Certifications
Edit `src/data/certifications.js` and add credential URLs/images when available.

## Assets
Place optional files here:
- `public/resume.pdf`
- `public/profile.jpg`
- `public/projects/*`
- `public/certificates/*`

Missing project/profile images do not break the UI; the interface falls back gracefully.

## Contact form
By default, the form uses a `mailto:` fallback so there are no secrets or API keys in the frontend. For a real API/email provider, set `VITE_CONTACT_ENDPOINT` in a local `.env` file based on `.env.example`. Never place private API credentials in Vite client-side variables.

## Deployment
This is a static Vite app. Deploy the generated `dist/` directory to any static hosting provider that supports SPA/static sites. Update the canonical URL and sitemap URL in `index.html` and `public/sitemap.xml` before production.

## Accessibility
The site uses semantic sections, keyboard-focusable controls, labels for forms, alt text for profile imagery, responsive touch targets and a `prefers-reduced-motion` media query.

## Project structure
```text
src/
├── components/
├── data/
├── hooks/
├── utils/
├── App.jsx
├── main.jsx
└── styles.css
public/
├── projects/
├── certificates/
├── robots.txt
└── sitemap.xml
```

## Maintenance principle
Do not edit component files just to add portfolio content. Prefer the matching file in `src/data/`. Components consume arrays/objects and render whatever is present, including empty states when a collection is empty.
